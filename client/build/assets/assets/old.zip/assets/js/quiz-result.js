/*
 * js file for quiz result page
 * query parameter contains mental status
 */



// create div with some information


// // reference links suggestions
// let text1 = "Read Suggestions 1";
// document.querySelector("#links").innerHTML = text1.link("https://www.google.com");
// let linkElement = document.createElement("h4");
// linkElement.textContent = "Read Suggestion";
// let linkList = document.querySelector("#links");
// linkList.appendChild(linkElement);

// other option for video
$(document).ready(function () {
  $(".slider").slider({ full_width: true, duration: 1000 });
  $(".slider").slider("pause");
});

// let submitButtonEl = document.createElement("button");
// submitButtonEl.id = "quizSubmitButton";
// submitButtonEl.textContent = "Submit";
// contentDivEl.appendChild(submitButtonEl);

